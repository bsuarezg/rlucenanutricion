INSTRUCCIONES DE INSTALACIÓN
===========================

1. Subir archivos
-----------------
Sube todo el contenido de la carpeta 'public_html' a la raíz de tu hosting (normalmente la carpeta 'public_html' o 'www').

La estructura final debería verse así en tu servidor:
/public_html
  /assets
  /api
  index.html
  ... otros archivos

2. Permisos
-----------
Es CRUCIAL asegurar que la carpeta 'api/db' tenga permisos de escritura.
El servidor PHP necesita poder crear y escribir en el archivo 'nutrition.db'.

Normalmente, debes asignar permisos 775 o 777 a la carpeta:
/public_html/api/db

3. Base de Datos
----------------
La base de datos es un archivo SQLite que se creará automáticamente la primera vez que se ejecute la aplicación (o uses la API).
Se encuentra en /api/db/nutrition.db.
Esta carpeta está protegida para que nadie pueda descargar la base de datos desde el navegador.

4. Usuario Administrador
------------------------
Se creará un usuario administrador por defecto:
Usuario: rlucena
Contraseña: Gilb3rt01+

5. Solución de Problemas
------------------------
- Si ves un error 404 al intentar hacer login, asegúrate de que tu hosting soporta archivos .htaccess y que el módulo mod_rewrite está activado (esto es estándar en casi todos los hostings PHP).
- Si ves un error 500, verifica los logs de error de tu servidor. Frecuentemente es un problema de permisos en la carpeta 'db'.

6. Seguridad
------------
La carpeta 'api/db' contiene un archivo .htaccess que bloquea el acceso web a la base de datos. No lo borres.
